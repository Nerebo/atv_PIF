#include <stdio.h>

int main(){
  int A, B, X;
  scanf("%d", &A);
  scanf("%d", &B);

  X = A + B;
  printf("X = %d\n", X);
    
  return 0;
}